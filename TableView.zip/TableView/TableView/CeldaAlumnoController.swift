//
//  CeldaAlumnoController.swift
//  TableView
//
//  Created by Alumno on 27/09/21.
//  Copyright © 2021 RubenBorbolla. All rights reserved.
//

import Foundation
import UIKit

class CeldaAlumnoController : UITableViewCell {
    @IBOutlet weak var lblAlumno: UILabel!
    @IBOutlet weak var lblMatricula: UILabel!
    @IBOutlet weak var lblPromedio: UILabel!
    
}
